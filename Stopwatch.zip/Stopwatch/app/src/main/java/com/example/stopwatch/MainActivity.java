package com.example.stopwatch;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    public int sec;
    public TextView t1;
    public Boolean running;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sec=0;
        t1 = findViewById(R.id.timer);
        running = false;

        if(savedInstanceState != null)
        {
            sec=savedInstanceState.getInt("seconds",12);
            running=savedInstanceState.getBoolean("run");
        }
        runTimer();

    }
    public void runTimer(){
        Handler h = new Handler();
        h.post(new Runnable() {
            @Override
            public void run() {
                if (running){
                    sec++;
                }
                int hours = sec / 3600;
                int mints = (sec % 3600) / 60;
                int secs = sec % 60;
                String s;
                s = String.format(Locale.getDefault(), "%2d:%2d:%2d", hours, mints, secs);
                t1.setText(s);
                h.postDelayed(this, 1000);
            }
        });
    }

    public void anStart(View view) {
        running=true;
    }

    public void anStop(View view) {
        running=false;
    }

    public void anReset(View view) {
        running=false;
        sec=0;
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {

        outState.putInt("seconds",sec);
        outState.putBoolean("run",running);
        super.onSaveInstanceState(outState);
    }
}