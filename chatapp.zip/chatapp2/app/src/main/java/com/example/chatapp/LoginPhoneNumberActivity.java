package com.example.chatapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hbb20.CountryCodePicker;

public class LoginPhoneNumberActivity extends AppCompatActivity {
CountryCodePicker countryCodePicker;
EditText phoneInput;
Button sendOtpBtn;
ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login_phone_number);
        countryCodePicker=findViewById(R.id.login_countrycode);
        phoneInput=findViewById(R.id.login_mobile_number);
        progressBar=findViewById(R.id.login_progressbar);
        progressBar.setVisibility(View.GONE);
        sendOtpBtn=findViewById(R.id.send_otp_btn);
        countryCodePicker.registerCarrierNumberEditText(phoneInput);
        sendOtpBtn.setOnClickListener((v) -> {
           if( !countryCodePicker.isValidFullNumber()){
               phoneInput.setError("invalid phone number");
               return;
           }
            Intent intent=new Intent(LoginPhoneNumberActivity.this,LoginOtpActivity.class);
           intent.putExtra("phone",countryCodePicker.getFullNumberWithPlus());
           startActivity(intent);
        });

    }
}