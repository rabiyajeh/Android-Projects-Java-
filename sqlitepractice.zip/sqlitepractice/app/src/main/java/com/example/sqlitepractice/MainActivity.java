package com.example.sqlitepractice;

import android.os.Bundle;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        mydbhelper dbhelper= new mydbhelper(this);
        //dbhelper.addContact("Rabbiya","1234567");
       ArrayList<contactModel>arrContacts= dbhelper.fetchcontact();
       for (int i=0; i<arrContacts.size();i++)
           Log.d("contacts", "name" +arrContacts.get(i).name + ", Phone "+arrContacts.get(i).phone);

    }


}