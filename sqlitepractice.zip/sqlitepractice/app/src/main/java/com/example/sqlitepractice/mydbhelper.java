package com.example.sqlitepractice;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class mydbhelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME="contacts";
    private static final String TABLE_NAME="contacts";
    private static final String KEY_ID="id";
    private static final String KEY_NAME="name";
    private static final String KEY_PHONE="phone";
    private static final int DATABASE_VERSION=1;

    public mydbhelper( Context context) {
        super(context,DATABASE_NAME,null,DATABASE_VERSION);
    }

    public void addContact(String name, String phone) {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put(KEY_NAME,name);
        values.put(KEY_PHONE,phone);
        db.insert(TABLE_NAME,null,values);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_NAME+ "(" + KEY_ID+ "INTEGER PRIMARY KEY AUTOINCREMENT,"+KEY_NAME+"TEXT,"+KEY_PHONE+"TEXT)" );




    }
    @SuppressLint("Recycle")
    public ArrayList<contactModel> fetchcontact(){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor cursor=db.rawQuery("SELECT * FROM " + TABLE_NAME,null);
        ArrayList<contactModel> arrContacts = new ArrayList<>();
        while (cursor.moveToNext()){
            contactModel model = new contactModel();
            model.id = cursor.getInt(0);
            model.name=cursor.getString(1);
            model.phone=cursor.getString(2);
            arrContacts.add(model);



        }
        return arrContacts;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
             db.execSQL("DROP TABLE IF EXISTS "+ TABLE_NAME);
            onCreate(db);
    }

}
