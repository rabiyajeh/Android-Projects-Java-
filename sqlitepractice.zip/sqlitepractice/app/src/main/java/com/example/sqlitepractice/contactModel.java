package com.example.sqlitepractice;

public class contactModel {
    int id;
    String name;
    String phone;

}
